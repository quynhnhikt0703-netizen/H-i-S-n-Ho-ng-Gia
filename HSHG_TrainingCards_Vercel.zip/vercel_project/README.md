# 🦐 Thẻ Đào Tạo · Hải Sản Hoàng Gia

**10 Tình Huống Khách Hàng Phổ Biến — Kịch Bản Xử Lý Toàn Diện**

Ứng dụng thẻ đào tạo tương tác cho nhân viên FOH, Thu ngân, Quản lý Chi nhánh.

---

## Deploy lên Vercel (3 bước)

### Cách 1 — Vercel CLI (nhanh nhất)

```bash
# 1. Cài Vercel CLI
npm i -g vercel

# 2. Vào thư mục project
cd vercel_project

# 3. Deploy
vercel --prod
```

### Cách 2 — Kéo thả lên Vercel Dashboard

1. Mở [vercel.com/new](https://vercel.com/new)
2. Chọn **"Deploy without Git"** → kéo thả toàn bộ thư mục này vào
3. Nhấn **Deploy** → nhận link ngay

### Cách 3 — GitHub (khuyến nghị để cập nhật dễ)

```bash
# 1. Tạo repo GitHub mới
git init
git add .
git commit -m "Initial: HSHG Training Cards"
git remote add origin https://github.com/YOUR_ORG/hshg-training-cards.git
git push -u origin main

# 2. Kết nối Vercel với repo:
#    vercel.com/new → Import Git Repository → chọn repo này → Deploy
```

---

## Cấu trúc file

```
vercel_project/
├── index.html      ← Toàn bộ app (tự chứa, không cần build)
├── vercel.json     ← Cấu hình headers + routing
└── README.md       ← File này
```

---

## Tính năng

| Tính năng | Mô tả |
|-----------|-------|
| 🃏 Thẻ lật | 10 thẻ flip card, nhấn để xem mặt sau |
| 🔵 Mặt trước | Số thẻ, icon, tiêu đề, mức độ, dấu hiệu nhận biết, trích dẫn review thực tế |
| 🟢 Mặt sau | 4 ô: NGĂN NGỪA / NÓI GÌ / LÀM GÌ / AI GIẢI QUYẾT |
| ⬅➡ Điều hướng | Mũi tên + dots indicator + grid tổng quan 10 thẻ |
| 🖨 In | Nút in ra bộ thẻ vật lý (A4 landscape, 2 mặt) |
| 📱 Responsive | Hoạt động tốt trên điện thoại, tablet, desktop |

---

## Cập nhật nội dung

Toàn bộ nội dung 10 thẻ nằm trong mảng `DATA` ở cuối file `index.html`.

Mỗi thẻ có cấu trúc:
```json
{
  "n": "01",
  "icon": "ti-fish",
  "title": "Tên tình huống",
  "ch": "Bộ phận liên quan",
  "sev": "TRUNG BÌNH",
  "sl": 2,
  "sig": ["Dấu hiệu 1", "Dấu hiệu 2", "Dấu hiệu 3"],
  "qt": "Trích dẫn review thực tế",
  "pre": ["Ngăn ngừa 1", "Ngăn ngừa 2", "Ngăn ngừa 3"],
  "say": ["say:\"Câu nói đúng\"", "warn:KHÔNG: câu nói sai"],
  "act": ["Hành động 1", "Hành động 2", "Hành động 3"],
  "who": "NV cấp 1 → Quản lý Ca → Quản lý CH"
}
```

`sl` (severity level): 1=Thấp, 2=Trung bình, 3=Cao, 4=Nghiêm trọng

---

*Tập Đoàn Hải Sản Hoàng Gia · Phòng Operations & OD · 2026*
