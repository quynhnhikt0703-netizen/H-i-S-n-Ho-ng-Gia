# 🦞 HSHG Learning Portal

AI-powered learning tracker cho nhân viên Tập Đoàn Hải Sản Hoàng Gia.

## Stack
- **Backend**: Node.js + Express + Anthropic SDK (streaming)
- **Frontend**: Vanilla HTML/CSS/JS (single file, zero dependency)
- **AI**: Claude claude-sonnet-4-20250514 qua Anthropic API

---

## Cài đặt & Chạy

### Bước 1 — Clone & Install
```bash
npm install
```

### Bước 2 — Cấu hình API Key
```bash
cp .env.example .env
# Mở .env và thêm ANTHROPIC_API_KEY của bạn
```

Lấy API key tại: https://console.anthropic.com

### Bước 3 — Chạy server
```bash
# Development (auto-restart khi sửa code)
npm run dev

# Production
npm start
```

Server chạy tại: **http://localhost:3000**

---

## Tính năng

### Nhân viên
- ✅ Đăng nhập bằng mã nhân viên + tên
- ✅ Xem danh sách module theo trạm bếp (6 trạm × 4 tier)
- ✅ Chat AI streaming với trợ lý đào tạo HSHG
- ✅ Quick actions: Kiểm tra nhanh, SOP chuẩn, Mẹo thực chiến
- ✅ Theo dõi tiến độ học từng module
- ✅ Auto-cập nhật progress khi làm quiz

### Manager (API endpoints)
- `GET /api/modules` — Danh sách tất cả modules
- `GET /api/progress/:employeeId` — Tiến độ theo nhân viên
- `GET /api/stats/:employeeId` — Thống kê tổng hợp theo trạm
- `POST /api/progress` — Cập nhật tiến độ thủ công

---

## Mở rộng lên Production

### Database
Thay `progressDB` trong `server.js` bằng PostgreSQL:
```javascript
// Cài: npm install pg
const { Pool } = require("pg");
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
```

### Auth
Tích hợp JWT hoặc session-based auth cho đăng nhập an toàn.

### Thêm modules
Mở `server.js` → mảng `MODULES` → thêm module mới theo format:
```javascript
{
  id: "STATION-TIER-SEQ",   // vd: TS-T1-003
  station: "Hải Sản Tươi Sống",
  tier: 1,
  name: "Tên module",
  duration: 45,             // phút
  desc: "Mô tả ngắn",
  objectives: ["Mục tiêu 1", "Mục tiêu 2"],
  sop: ["Bước 1...", "Bước 2..."],
  keyPoints: ["Điểm quan trọng 1", "Điểm quan trọng 2"],
}
```

### Deploy
```bash
# Render / Railway / Fly.io
# Set environment variable: ANTHROPIC_API_KEY=sk-ant-...
```

---

## Kiến trúc API Chat

```
Browser
  │── POST /api/chat { messages, module, employeeId }
  │
Server (server.js)
  │── buildSystemPrompt(module) → System prompt HSHG-specific
  │── anthropic.messages.stream(...)
  │── SSE stream → "data: {"type":"text","text":"..."}\n\n"
  │
Browser (index.html)
  └── ReadableStream reader → append token vào bubble
```

Streaming giúp phản hồi xuất hiện realtime, không cần chờ toàn bộ response.

---

## Liên hệ & Customize
Chỉnh `buildSystemPrompt()` trong `server.js` để thêm ngữ cảnh HSHG cụ thể hơn (BOM thực tế, giá nguyên liệu, tiêu chuẩn từng chi nhánh).
