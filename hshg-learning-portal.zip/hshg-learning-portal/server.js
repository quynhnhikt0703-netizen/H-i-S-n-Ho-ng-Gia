require("dotenv").config();
const express = require("express");
const Anthropic = require("@anthropic-ai/sdk");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ai = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const MODULES = [
  { id:"TS-T1-001", station:"Hải Sản Tươi Sống", tier:1, name:"Sơ chế Tôm Hùm", duration:45, desc:"Kỹ thuật sơ chế, kiểm tra chất lượng và bảo quản tôm hùm theo chuẩn HSHG. Yield chuẩn BOM: 85%.", objectives:["Nhận biết tôm hùm tươi sống đạt chuẩn","Thực hiện quy trình 5 bước sơ chế","Kiểm soát yield: cân trước/sau","Bảo quản đúng nhiệt độ 0–4°C"], sop:["Kiểm tra chất lượng: màu sắc, mùi, độ hoạt động","Cân trước sơ chế → ghi phiếu kiểm soát","Sơ chế: tách đầu, làm sạch chỉ đen, rửa nước lạnh","Cân sau sơ chế → tính % hao hụt","Trình bày trên khay đá, dán nhãn, lưu tủ 0–4°C"], keyPoints:["Yield chuẩn 85% — thấp hơn báo ngay Bếp trưởng","Không sơ chế tôm chết quá 30 phút","Dụng cụ hải sản KHÔNG dùng chung với thực phẩm khác"] },
  { id:"TS-T1-002", station:"Hải Sản Tươi Sống", tier:1, name:"Sơ chế Cua Hoàng Đế", duration:60, desc:"Quy trình sơ chế cua hoàng đế, kiểm soát chất lượng và định lượng chuẩn BOM (yield 78%).", objectives:["Kiểm tra cua sống đạt chuẩn","Kỹ thuật sơ chế an toàn","Định lượng theo BOM","Bảo quản đúng chuẩn"], sop:["Kiểm tra cua: còn sống, đủ càng","Gây mê bằng đá lạnh 10 phút","Cân trước → sơ chế → cân sau (yield 78%)","Làm sạch yếm, mang, dạ dày — giữ gạch cua","Bảo quản khay đá, bọc màng, tối đa 2 giờ"], keyPoints:["Gạch cua là điểm bán hàng cao cấp — không bỏ","Yield thấp hơn cua thường — đừng so sánh nhầm","Báo ngay khi cua chết trước sơ chế"] },
  { id:"TS-T2-001", station:"Hải Sản Tươi Sống", tier:2, name:"Kỹ thuật hấp Hải Sản", duration:90, desc:"Kiểm soát thời gian, nhiệt độ hấp cho từng loại hải sản. Nhận biết hải sản chín đúng chuẩn.", objectives:["Thuộc bảng thời gian hấp từng loại","Kiểm soát nhiệt độ ổn định","Nhận biết hải sản chín chuẩn HSHG","Xử lý sự cố hấp chưa chín/quá"], sop:["Nước sạch không quá 1/3 nồi","Gia nhiệt đến khi bốc hơi mạnh mới cho hải sản vào","Đặt lên vỉ — không xếp chồng","Canh thời gian theo bảng chuẩn","Kiểm tra bằng que thử","Lấy ra ngay khi chín"], keyPoints:["Tôm hùm 400–600g: 12–15 phút","Cua 800g–1kg: 18–20 phút","Sò điệp: 5–7 phút","Nghêu: mở vỏ là chín (3–5 phút)"] },
  { id:"TS-T3-001", station:"Hải Sản Tươi Sống", tier:3, name:"Kiểm soát chất lượng nhập hàng", duration:60, desc:"Kiểm tra chất lượng hải sản khi nhập kho: nhận biết dấu hiệu không đạt, từ chối hàng, báo cáo procurement.", objectives:["Kiểm tra 15 loại hải sản HSHG","Lập phiếu kiểm soát đúng form","Quy trình từ chối hàng không đạt","Báo cáo procurement kịp thời"], sop:["Đối chiếu hóa đơn với PO","Cân kiểm tra mẫu 10% lô hàng","Kiểm tra cảm quan: màu, mùi, kết cấu","Kiểm tra nhiệt độ vận chuyển (≤4°C)","Ký nhận hoặc từ chối theo form HSHG","Chụp ảnh lô không đạt — gửi nhóm Procurement"], keyPoints:["Không nhận hải sản có mùi amoniac mạnh","Mắt trong, thịt đàn hồi, không nhớt","Nhiệt độ giao hàng > 6°C → từ chối toàn bộ lô"] },
  { id:"NU-T1-001", station:"Nướng & Hơi", tier:1, name:"Kỹ thuật nướng than cơ bản", duration:60, desc:"Chuẩn bị than, nhóm lửa, kiểm soát nhiệt độ và kỹ thuật nướng đều nhiệt cho hải sản HSHG.", objectives:["Nhóm than đúng kỹ thuật","Phân biệt 3 mức nhiệt","Nướng đều 2 mặt đúng thời gian","Vệ sinh vỉ nướng đúng quy trình"], sop:["Chuẩn bị than nhãn HSHG phê duyệt","Nhóm lửa bằng mồi than — không dùng xăng/cồn","Chờ than đỏ đều, hết khói đen mới nướng","Thoa dầu lên vỉ trước khi đặt hải sản","Nướng mặt 1 — KHÔNG lật quá sớm","Lật 1 lần — nướng mặt 2 đến chuẩn","Vệ sinh vỉ ngay sau mỗi mẻ"], keyPoints:["Than đỏ hoàn toàn — lửa xanh còn khói = hỏng mùi","Tôm: 3–4 phút/mặt","Mực: 2–3 phút/mặt","Cá: 5–7 phút/mặt"] },
  { id:"NU-T2-001", station:"Nướng & Hơi", tier:2, name:"Nướng hải sản với sốt HSHG", duration:75, desc:"Kỹ thuật áp sốt đúng thời điểm, kiểm soát caramel hóa và giữ hương vị đặc trưng.", objectives:["Thuộc 5 loại sốt nướng HSHG và tỉ lệ pha","Áp sốt đúng thời điểm tránh cháy","Caramel đẹp không cháy đen","Trình bày đúng chuẩn service"], sop:["Chuẩn bị sốt đúng tỉ lệ HSHG","Nướng sơ 70% thời gian trước khi áp sốt","Áp sốt lần 1 — đợi 1 phút keo lại","Lật — áp sốt mặt còn lại","Áp sốt lần cuối — tăng nhiệt 30 giây","Lấy ra ngay"], keyPoints:["Sốt có đường: áp muộn — áp sớm sẽ cháy","Caramel đẹp = vàng nâu không phải đen","Lấy ra ngay khi đạt màu"] },
  { id:"LA-T1-001", station:"Lẩu", tier:1, name:"Nước dùng Lẩu chuẩn HSHG", duration:90, desc:"Công thức nước dùng lẩu hải sản đặc trưng HSHG. Định lượng BOM, kiểm soát vị, nấu nhất quán.", objectives:["Thuộc công thức nước dùng cơ bản","Định lượng đúng BOM","Canh vị: ngọt thanh không mặn chát","Duy trì nồi lẩu trong suốt buổi"], sop:["Chuẩn bị xương/tôm khô/củ quả theo BOM","Hầm xương 4 tiếng — hớt bọt thường xuyên","Phi thơm hành tím, sả, gừng","Kết hợp nước hầm + gia vị theo tỉ lệ","Nêm nếm: ngọt thanh, umami, không mặn","Lọc qua rây — giữ nóng 85°C"], keyPoints:["Ngọt từ xương thật — không dùng hạt nêm nhiều","Màu vàng trong hoặc đỏ tươi (tomyum)","Không hâm lại nước dùng đã phục vụ"] },
  { id:"LA-T2-001", station:"Lẩu", tier:2, name:"Lẩu Tomyum Hải Sản", duration:75, desc:"Công thức lẩu Tomyum hải sản HSHG — cân bằng chua, cay, thơm đúng chuẩn.", objectives:["Pha Tomyum đúng tỉ lệ HSHG","Kiểm soát độ chua cay theo phản hồi bàn","Thêm hải sản đúng thứ tự","Điều chỉnh vị khi phục vụ"], sop:["Phi thơm sả, lá chanh, riềng, ớt","Thêm nước dùng hải sản — đun sôi","Thêm Tomyum paste theo tỉ lệ BOM","Nêm: nước mắm, đường phèn, chanh","Thêm hải sản: cua → tôm → mực → nghêu","Rắc ngò gai, lá chanh khi phục vụ"], keyPoints:["Không quá cay — khách gia đình, nhóm lớn","Chanh vắt cuối — nấu chung sẽ đắng","Paste Tomyum đã có muối — nêm từng chút"] },
  { id:"KV-T1-001", station:"Khai Vị", tier:1, name:"Gỏi Hải Sản HSHG", duration:30, desc:"Kỹ thuật làm gỏi, pha nước chấm và trình bày đĩa gỏi hải sản theo chuẩn HSHG.", objectives:["Sơ chế rau gỏi đúng kỹ thuật","Pha nước chấm đúng tỉ lệ BOM","Trộn gỏi đúng thứ tự","Plating đúng chuẩn HSHG"], sop:["Rửa, thái rau gỏi — ráo nước hoàn toàn","Hấp/luộc hải sản đúng chín — để nguội","Pha nước trộn: chanh + đường + mắm + tỏi ớt","Trộn rau trước — hải sản sau","Nếm vị: chua ngọt mặn cân bằng","Trình bày cao tự nhiên, rắc đậu phộng"], keyPoints:["Trộn xong phục vụ ngay — không để lâu","Hải sản nguội hoàn toàn mới trộn","Đậu phộng rang rắc sau cùng giữ độ giòn"] },
  { id:"KV-T2-001", station:"Khai Vị", tier:2, name:"Plating Premium Hải Sản", duration:45, desc:"Kỹ thuật trình bày cao cấp cho các món khai vị hải sản HSHG.", objectives:["Nguyên tắc plating 5 yếu tố HSHG","Thực hành 3 kiểu trình bày chuẩn","Kiểm soát phần ăn nhất quán","Dùng đúng đồ trang trí theo mùa"], sop:["Kiểm tra đĩa: sạch, đúng nhiệt độ","Đặt thành phần chính trước (focal point)","Garnish theo nguyên tắc lẻ (1 hoặc 3 điểm)","Sauce: chấm điểm hoặc kéo cước","Kiểm tra từ góc nhìn 45°","Lau viền đĩa trước khi ra bàn"], keyPoints:["Ít là nhiều — không cần quá nhiều trang trí","Màu sắc: contrast giữa hải sản và garnish","Chiều cao tạo visual ấn tượng"] },
  { id:"DU-T1-001", station:"Đồ Uống", tier:1, name:"Wine Service cơ bản", duration:60, desc:"Quy trình phục vụ wine chuyên nghiệp tại HSHG: giới thiệu, mở chai, rót đúng chuẩn.", objectives:["Giới thiệu wine menu đúng cách","Mở chai wine không vỡ nút","Rót đúng 150ml/ly","Bảo quản wine mở đúng kỹ thuật"], sop:["Trình wine menu — gợi ý theo món và ngân sách","Đưa chai khách xem nhãn trước khi mở","Mở bằng sommelier knife","Rót một chút để khách nếm — đợi xác nhận","Rót đủ 150ml — khăn trắng dưới chai","Đặt vào ice bucket hoặc wine rack đúng loại"], keyPoints:["Red wine: 16–18°C — KHÔNG để trong tủ đá","White/Rosé: 8–12°C — luôn trong ice bucket","Wine mở: dùng trong 3 ngày"] },
  { id:"DU-T2-001", station:"Đồ Uống", tier:2, name:"Food & Wine Pairing HSHG", duration:75, desc:"Ghép đôi wine với thực đơn hải sản HSHG — upsell tự nhiên và tăng trải nghiệm khách.", objectives:["Thuộc 10 cặp ghép đôi chuẩn HSHG","Giải thích pairing cho khách đơn giản","Kỹ năng upsell không gây áp lực","Xử lý khi khách không uống wine"], sop:["Lắng nghe khách chọn món trước","Gợi ý wine phù hợp — tone nhẹ nhàng","Giải thích ngắn lý do ghép đôi (1–2 câu)","Đề xuất cả chai và theo ly","Khách ngại wine: gợi ý cocktail/mocktail"], keyPoints:["Hải sản trắng → Sauvignon Blanc, Pinot Grigio","Cua, Tôm Hùm → Chardonnay oaked nhẹ","Nướng than đậm → Rosé hoặc Pinot Noir nhẹ","Lẩu cay → Riesling off-dry hoặc beer thủ công"] },
  { id:"TM-T1-001", station:"Tráng Miệng", tier:1, name:"Dessert chuẩn HSHG", duration:45, desc:"Chuẩn bị và trình bày các món tráng miệng HSHG — kiểm soát nhiệt độ phục vụ và visual.", objectives:["Chuẩn bị 5 món tráng miệng cơ bản","Kiểm soát nhiệt độ phục vụ đúng","Trình bày đúng chuẩn thương hiệu","Đúng thời gian giờ cao điểm"], sop:["Kiểm tra stock đầu ca","Chuẩn bị sẵn các phần trước giờ cao điểm","Giữ nhiệt độ phục vụ phù hợp","Trình bày theo ảnh chuẩn","Ra bàn ngay sau khi hoàn thành"], keyPoints:["Kem: -5°C đến -8°C — không để chảy","Món nóng: phục vụ ngay","Dessert = ấn tượng cuối — ảnh hưởng review"] },
];

const progressDB = {};
const DEFAULT_PROGRESS = {
  "TS-T1-001":{ progress:100, score:92 }, "TS-T1-002":{ progress:85, score:78 },
  "TS-T2-001":{ progress:60,  score:null }, "NU-T1-001":{ progress:80, score:85 },
  "NU-T2-001":{ progress:20,  score:null }, "LA-T1-001":{ progress:100, score:95 },
  "LA-T2-001":{ progress:15,  score:null }, "KV-T1-001":{ progress:40, score:null },
  "DU-T1-001":{ progress:0,   score:null },
};

// GET modules
app.get("/api/modules", (req, res) => res.json(MODULES));

// GET progress
app.get("/api/progress/:id", (req, res) => {
  if (!progressDB[req.params.id]) progressDB[req.params.id] = { ...DEFAULT_PROGRESS };
  res.json(progressDB[req.params.id]);
});

// POST progress
app.post("/api/progress", (req, res) => {
  const { employeeId, moduleId, progress, score } = req.body;
  if (!progressDB[employeeId]) progressDB[employeeId] = { ...DEFAULT_PROGRESS };
  progressDB[employeeId][moduleId] = {
    progress: Math.min(100, Math.max(0, parseInt(progress) || 0)),
    score: score ?? progressDB[employeeId][moduleId]?.score ?? null,
    updatedAt: new Date().toISOString(),
  };
  res.json({ success: true });
});

// POST chat — gọi Claude Haiku, trả về JSON đơn giản
app.post("/api/chat", async (req, res) => {
  const { messages, module } = req.body;
  if (!messages || !module) return res.status(400).json({ error: "Thiếu messages hoặc module" });

  try {
    const response = await ai.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 800,
      system: `Bạn là AI Trợ Lý Đào Tạo của Hải Sản Hoàng Gia (HSHG).
Module: ${module.name} (${module.station} - Tier ${module.tier})
Mô tả: ${module.desc}
SOP: ${(module.sop||[]).join(" | ")}
Điểm chính: ${(module.keyPoints||[]).join(" | ")}
Quy tắc: Dùng tiếng Việt, ngắn gọn, thực chiến. "Kiểm tra nhanh"→3 câu hỏi. "SOP chuẩn"→từng bước. "Mẹo thực chiến"→3-4 tip. Dùng bullet points.`,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
    });

    res.json({ reply: response.content[0].text });

  } catch (err) {
    console.error("[Lỗi Claude]", err.message);
    res.status(500).json({ error: "Lỗi API: " + err.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n🦞 HSHG Learning Portal`);
  console.log(`   http://localhost:${PORT}`);
  console.log(`   API Key: ${process.env.ANTHROPIC_API_KEY ? "✅ OK" : "❌ Thiếu ANTHROPIC_API_KEY"}\n`);
});
